
"""
Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
Checks whether config recorder and delivery channels are available and deletes them accross all region a
Services: Amazon Cloudwatch EventBridge (trigger), AWS Lambda, AWS CloudFormation and S3
Python 3.9 - Lambda - Last Modified 05/17/2022
"""

import sys
import json
import infra_utilities
import argparse
from colorama import init, Fore
from botocore.exceptions import ClientError
from prettytable import PrettyTable
import boto3
import logging
import os

def lambda_handler(event, context):
	print(event)

	# Product Id of the AWS Control Tower Account Factory
	product_id = os.environ["PRODUCT_ID"]

	# Provisioning Artifact Id of the AWS Control Tower Account Factory
	provisioning_artifact_id = os.environ["PROVISIONING_ARTIFACT_ID"]


	region_list = ['us-east-1', 'us-east-2', 'us-west-2', 'eu-west-1', 'ap-southeast-2', 'ap-southeast-1', 'eu-central-1',
			  'eu-north-1', 'eu-west-2', 'ca-central-1']

	organization_unit = os.environ["ORGANIZATION_UNIT"]
	sou = os.environ["SOURCE_ORGANIZATION_UNIT"]

	account_id = event['detail']['userIdentity']['accountId']
	print(account_id)
	check_account(account_id,product_id,provisioning_artifact_id,region_list,organization_unit,sou)
	
	return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

def check_account(account_id,product_id,provisioning_artifact_id,region_list,organization_unit,sou):
	
	account_id = account_id
	sts_connection = boto3.client('sts')
	acct_b = sts_connection.assume_role(
		RoleArn="arn:aws:iam::"+account_id+":role/AWSControlTowerExecution",
		RoleSessionName="cross_acct_lambda"
	)

	ERASE_LINE = '\x1b[2K'
	account_credentials = {'AccessKeyId': acct_b['Credentials']['AccessKeyId'],
	                       'SecretAccessKey': acct_b['Credentials']['SecretAccessKey'],
	                       'SessionToken': acct_b['Credentials']['SessionToken'],
	                       'AccountNumber': account_id}

	print()
	ExplainMessage = """
	Objective: This script aims to identify issues and make it easier to "adopt" an existing account into a Control Tower environment.
	
	1. There must be no active config channel and recorder in the account as “there can be only one” of each. This must also be deleted via CLI, not console, switching config off in the console is NOT good enough and just disables it. To Delete the delivery channel and the configuration recorder (can be done via CLI and Python script only):
	aws configservice describe-delivery-channels
	aws configservice describe-delivery-channel-status
	aws configservice describe-configuration-recorders
	aws configservice stop-configuration-recorder --configuration-recorder-name <NAME-FROM-DESCRIBE-OUTPUT>
	aws configservice delete-delivery-channel --delivery-channel-name <NAME-FROM-DESCRIBE-OUTPUT>
	aws configservice delete-configuration-recorder --configuration-recorder-name <NAME-FROM-DESCRIBE-OUTPUT
	"""


	print("This script does the following... ")
	print(Fore.BLUE+"  1."+Fore.RESET+" Checks the child account in each of the regions")
	print("     to see if there's already a "+Fore.RED+"Config Recorder and Delivery Channel "+Fore.RESET+"enabled...")
	print()

	def execute_steps(child_account_id, account_credentials, fix_run, region_list):

		def InitDict(StepCount):
			fProcessStatus = {}
			# fProcessStatus['ChildAccountIsReady']=True
			# fProcessStatus['IssuesFound']=0
			# fProcessStatus['IssuesFixed']=0
			for item in range(StepCount):
				Step = 'Step' + str(item)
				fProcessStatus[Step] = {}
				fProcessStatus[Step]['Success'] = True
				fProcessStatus[Step]['IssuesFound'] = 0
				fProcessStatus[Step]['IssuesFixed'] = 0
				fProcessStatus[Step]['ProblemsFound'] = []
			return (fProcessStatus)

		NumOfSteps = 11
		ProcessStatus = InitDict(NumOfSteps)

		# Step 1
		# This part will check the Config Recorder and  Delivery Channel. If they have one, we need to delete it, so we can create another. We'll ask whether this is ok before we delete.
		Step='Step1'
		try:
			print(Fore.BLUE + "{}:".format(Step) + Fore.RESET)
			print(" Checking account {} for a Config Recorders and Delivery Channels in any region".format(child_account_id))
			ConfigList=[]
			DeliveryChanList=[]
			"""
			TO-DO: Need to find a way to gracefully handle the error processing of opt-in regions.
				Until then - we're using a hard-coded listing of regions, instead of dynamically finding those.
			"""
			# region_list.remove('me-south-1')	# Opt-in region, which causes a failure if we check and it's not opted-in
			# region_list.remove('ap-east-1')	# Opt-in region, which causes a failure if we check and it's not opted-in
			for region in region_list:
				print(ERASE_LINE, "Checking account {} in region {} for Config Recorder".format(child_account_id, region), end='\r')
				logging.info("Looking for Config Recorders in account %s from Region %s", child_account_id, region)
				# ConfigRecorder=client_cfg.describe_configuration_recorders()
				ConfigRecorder=infra_utilities.find_config_recorders(account_credentials, region)
				logging.debug("Tried to capture Config Recorder")
				if len(ConfigRecorder['ConfigurationRecorders']) > 0:
					ConfigList.append({
						'Name': ConfigRecorder['ConfigurationRecorders'][0]['name'],
						'roleARN': ConfigRecorder['ConfigurationRecorders'][0]['roleARN'],
						'AccountID': child_account_id,
						'Region': region
					})
				print(ERASE_LINE, "Checking account {} in region {} for Delivery Channel".format(child_account_id, region), end='\r')
				DeliveryChannel=infra_utilities.find_delivery_channels(account_credentials, region)
				logging.debug("Tried to capture Delivery Channel")
				if len(DeliveryChannel['DeliveryChannels']) > 0:
					DeliveryChanList.append({
						'Name': DeliveryChannel['DeliveryChannels'][0]['name'],
						'AccountID': child_account_id,
						'Region': region
					})
			print("Delivery Channel list",DeliveryChanList)
			print("ConfigList", ConfigList)
			logging.error("Checked account %s in %s regions. Found %s issues with Config Recorders and Delivery Channels", child_account_id, len(region_list), len(ConfigList)+len(DeliveryChanList))
		except ClientError as my_Error:
			logging.warning("Failed to capture Config Recorder and Delivery Channels")
			ProcessStatus[Step]['Success']=False
			print(my_Error)

		for i in range(len(ConfigList)):
			logging.error(Fore.RED+"Found a config recorder for account %s in region %s", ConfigList[i]['AccountID'], ConfigList[i]['Region']+Fore.RESET)
			ProcessStatus[Step]['Success']=False
			ProcessStatus[Step]['IssuesFound']+=1
			ProcessStatus[Step]['ProblemsFound'].append(ConfigList)
			if fix_run:
				logging.warning("Deleting %s in account %s in region %s", ConfigList[i]['Name'], ConfigList[i]['AccountID'], ConfigList[i]['Region'])
				DelConfigRecorder=infra_utilities.del_config_recorder(account_credentials, ConfigList[i]['Region'], ConfigList[i]['Name'])
				# We assume the process worked. We should probably NOT assume this.
				ProcessStatus[Step]['IssuesFixed']+=1
		for i in range(len(DeliveryChanList)):
			logging.error(Fore.RED+"I found a delivery channel for account %s in region %s", DeliveryChanList[i]['AccountID'], DeliveryChanList[i]['Region']+Fore.RESET)
			ProcessStatus[Step]['Success']=False
			ProcessStatus[Step]['IssuesFound']+=1
			ProcessStatus[Step]['ProblemsFound'].append(DeliveryChanList)
			if fix_run:
				logging.warning("Deleting %s in account %s in region %s", DeliveryChanList[i]['Name'], DeliveryChanList[i]['AccountID'], DeliveryChanList[i]['Region'])
				DelDeliveryChannel=infra_utilities.del_delivery_channel(account_credentials, DeliveryChanList[i]['Region'], DeliveryChanList[i]['Name'])
				# We assume the process worked. We should probably NOT assume this.
				ProcessStatus[Step]['IssuesFixed']+=1

		# ProcessStatus[Step]['ProblemsFound'].append()

		if ProcessStatus[Step]['Success']:
			print(ERASE_LINE+Fore.GREEN+"** Step 1 completed with no issues"+Fore.RESET)
		elif ProcessStatus[Step]['IssuesFound']-ProcessStatus[Step]['IssuesFixed']==0:
			print(ERASE_LINE+Fore.GREEN+"** Step 1 found {} issues, but they were fixed by deleting the existing Config Recorders and Delivery Channels".format(ProcessStatus[Step]['IssuesFound'])+Fore.RESET)
			ProcessStatus[Step]['Success']=True
		elif ProcessStatus[Step]['IssuesFound']>ProcessStatus[Step]['IssuesFixed']:
			print(ERASE_LINE+Fore.RED+"** Step 1 completed, but there were {} items found that weren't deleted".format(ProcessStatus[Step]['IssuesFound']-ProcessStatus[Step]['IssuesFixed'])+Fore.RESET)
		else:
			print(ERASE_LINE+Fore.RED+"** Step 1 completed with blockers found"+Fore.RESET)
		print()


		##### Function Summary #############
		TotalIssuesFound=0
		TotalIssuesFixed=0
		MemberReady=True
		for item in ProcessStatus:
			TotalIssuesFound=TotalIssuesFound + ProcessStatus[item]['IssuesFound']
			TotalIssuesFixed=TotalIssuesFixed + ProcessStatus[item]['IssuesFixed']
			MemberReady=MemberReady and ProcessStatus[item]['Success']

		ProcessStatus['AccountId'] = child_account_id
		ProcessStatus['Ready']=MemberReady
		ProcessStatus['IssuesFound']=TotalIssuesFound
		ProcessStatus['IssuesFixed']=TotalIssuesFixed
		return(ProcessStatus)


	OrgResults = []
	FixRun = True
	Results = execute_steps(account_credentials['AccountNumber'], account_credentials, FixRun, region_list)
	OrgResults.append(Results.copy())

	####
	# Summary at the end
	####
	Results=[]
	for account in OrgResults:
		# ChildAccountIsReady = True
		# NumberOfIssues = 0
		# NumberOfFixes = 0
		# for key in account.keys():
		# 	if key in ['AccountId', 'Ready', 'IssuesFound', 'IssuesFixed']:
		# 		continue
		# 	ChildAccountIsReady = account[key]['Success']
		# 	NumberOfIssues = NumberOfIssues + account[key]['IssuesFound']
		# 	NumberOfFixes = NumberOfFixes + account[key]['IssuesFixed']
		# 	logging.info("%s Success marker is: %s and therefore our process result will be %s", key, account[key]['Success'], ChildAccountIsReady)
		FixesWorked = (account['IssuesFound'] - account['IssuesFixed'] == 0)
		if account['Ready'] and account['IssuesFound'] == 0:
			print(Fore.GREEN+"**** We've found NO issues that would hinder the adoption of account {} ****".format(account['AccountId'])+Fore.RESET)
		elif account['Ready'] and FixesWorked:
			print(Fore.GREEN+"We've found and fixed"+Fore.RED, "{}".format(account['IssuesFixed'])+Fore.RESET, Fore.GREEN+"issues that would have otherwise blocked the adoption of account {}".format(account['AccountId'])+Fore.RESET)
		else:
			print(Fore.RED+"Account # {} has {} issues that would hinder the adoption of this account".format(account['AccountId'],account['IssuesFound'] - account['IssuesFixed'])+Fore.RESET)

	x = PrettyTable()
	y = PrettyTable()

	x.field_names = ['Account', 'Issues Found', 'Issues Fixed', 'Ready?']
	# The following headers represent Step0, Step2,
	#y.field_names = ['Account', 'Config Issue Count','Ready?', 'Output']
	for i in OrgResults:
		x.add_row([i['AccountId'],i['IssuesFound'],i['IssuesFixed'],i['Ready']])
		#y.add_row([i['AccountId'],i['Step1']['IssuesFound'] - i['Step1']['IssuesFixed'],'None Yet',i['Step1']['Success']])
	print("The following table represents the accounts looked at, and whether they are ready to be incorporated into a Control Tower environment.")
	print(x)
	print()
	#print("The following table represents the accounts looked at, and gives details under each type of issue as to what might prevent a successful migration of this account into a Control Tower environment.")
	#print(y)

	print("Describing the account details")
	account_name, account_email = infra_utilities.describe_account(account_credentials,account_id)

	print("Enrolling account to {} OU".format(organization_unit))
	infra_utilities.provision_account(account_id, account_name, account_email,product_id,provisioning_artifact_id,organization_unit,sou)