import logging
import boto3
import time
from botocore.exceptions import ClientError

def find_config_recorders(credentials, region):
	session_cfg=boto3.Session(
		aws_access_key_id=credentials['AccessKeyId'],
		aws_secret_access_key=credentials['SecretAccessKey'],
		aws_session_token=credentials['SessionToken'],
		region_name=region)
	client_cfg=session_cfg.client('config')
	logging.warning("Looking for Config Recorders in account %s from Region %s", credentials['AccountNumber'], region)
	response=client_cfg.describe_configuration_recorders()
	logging.info(response)
	return(response)


def del_config_recorder(credentials, region, config_recorder_name):
	session_cfg=boto3.Session(
		aws_access_key_id=credentials['AccessKeyId'],
		aws_secret_access_key=credentials['SecretAccessKey'],
		aws_session_token=credentials['SessionToken'],
		region_name=region)
	client_cfg=session_cfg.client('config')
	logging.error("Deleting Config Recorder %s from Region %s in account %s", config_recorder_name, region, credentials['AccountNumber'])
	response=client_cfg.delete_configuration_recorder(ConfigurationRecorderName=config_recorder_name)

def find_delivery_channels(credentials, region):
	session_cfg=boto3.Session(
		aws_access_key_id=credentials['AccessKeyId'],
		aws_secret_access_key=credentials['SecretAccessKey'],
		aws_session_token=credentials['SessionToken'],
		region_name=region)
	client_cfg=session_cfg.client('config')
	logging.warning("Looking for Delivery Channels in account %s from Region %s", credentials['AccountNumber'], region)

	response=client_cfg.describe_delivery_channels()
	return(response)


def del_delivery_channel(credentials, region, delivery_channel_name):
	session_cfg=boto3.Session(
		aws_access_key_id=credentials['AccessKeyId'],
		aws_secret_access_key=credentials['SecretAccessKey'],
		aws_session_token=credentials['SessionToken'],
		region_name=region)
	client_cfg=session_cfg.client('config')
	logging.error("Deleting Delivery Channel %s from Region %s in account %s", delivery_channel_name, region, credentials['AccountNumber'])
	response=client_cfg.delete_delivery_channel(DeliveryChannelName=delivery_channel_name)
	return(response)


def describe_account(credentials,accountid):
	client_cfg=boto3.client('organizations')
	response = client_cfg.describe_account(
		AccountId=accountid
	)
	account_name=response['Account']['Name']
	account_email=response['Account']['Email']
	return(account_name,account_email)

def provision_account(accountid,account_name,account_email,prod_id,pa_id,organization_unit,sou):
	client_cfg=boto3.client('servicecatalog')
	print(accountid)
	client = boto3.client('organizations')
	timestr = str(time.strftime("%Y%m%d-%H%M%S"))
	input_params = [
            {
                'Key': 'AccountEmail',
                'Value': account_email
            },
			{
				'Key': 'AccountName',
				'Value': account_name
			},
			{
				'Key': 'ManagedOrganizationalUnit',
				'Value': 'Sandbox'
			},
			{
				'Key': 'SSOUserEmail',
				'Value': account_email
			},
			{
				'Key': 'SSOUserFirstName',
				'Value': 'Archer'
			},
			{
				'Key': 'SSOUserLastName',
				'Value': 'Archer'
			},
        ]

	prov_prod_name = 'Enroll-Account-' + accountid +'-'+timestr
	response = client_cfg.provision_product(ProductId=prod_id,ProvisioningArtifactId=pa_id,ProvisionedProductName=prov_prod_name,PathName='AWS Control Tower Account Factory Portfolio',ProvisioningParameters=input_params)
	print(response)
	res = client.move_account(AccountId=str(accountid),SourceParentId=sou,DestinationParentId=organization_unit)
	print(res)